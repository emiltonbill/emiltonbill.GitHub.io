---
name: Leaflet.Control.Layers.Tree
category: layer-switching-controls
repo: https://github.com/jjimenezshaw/Leaflet.Control.Layers.Tree
author: Javier Jimenez Shaw
author-url: https://github.com/jjimenezshaw/
demo: https://jjimenezshaw.github.io/Leaflet.Control.Layers.Tree/examples/
compatible-v0:
compatible-v1: true
---

L.Control.Layers extension that supports a Tree structure, both for base and overlay layers. Simple and highly configurable.
