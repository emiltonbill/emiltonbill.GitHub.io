---
name: Leaflet.SelectLayers
category: layer-switching-controls
repo: https://github.com/vogdb/SelectLayersControl
author: vogdb
author-url: https://github.com/vogdb
demo: 
compatible-v0:
compatible-v1: true
---

a Leaflet plugin which adds new control to switch between different layers on the map. New control replaces L.Control.Layers radio button panel with select tag.
