---
name: Leaflet.GroupedLayerControl
category: layer-switching-controls
repo: https://github.com/ismyrnow/leaflet-groupedlayercontrol
author: Ishmael Smyrnow
author-url: https://github.com/ismyrnow
demo: https://ismyrnow.github.io/leaflet-groupedlayercontrol/example/advanced.html
compatible-v0:
compatible-v1: true
---

Leaflet layer control with support for grouping overlays together.
