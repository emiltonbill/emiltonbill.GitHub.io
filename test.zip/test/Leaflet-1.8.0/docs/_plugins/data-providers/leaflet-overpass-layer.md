---
name: Leaflet Overpass Layer
category: data-providers
repo: https://github.com/GuillaumeAmat/leaflet-overpass-layer
author: Guillaume AMAT
author-url: https://github.com/GuillaumeAmat
demo: https://leaflet-overpass-layer-demo.stackblitz.io/
compatible-v0:
compatible-v1: true
---

Easily include data from the <a href="http://overpass-api.de">overpass api</a>.
