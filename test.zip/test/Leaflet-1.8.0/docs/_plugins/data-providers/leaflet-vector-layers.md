---
name: Leaflet Vector Layers
category: data-providers
repo: http://jasonsanford.github.io/leaflet-vector-layers/
author: Jason Sanford
author-url: http://geojason.info/
demo: 
compatible-v0:
compatible-v1: true
---

Allows to easily create vector layers from a number of geo web services, such as ArcGIS Server, Arc2Earth, GeoIQ, CartoDB and GIS Cloud.
