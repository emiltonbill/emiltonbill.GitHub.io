---
name: leaflet-velocity
category: dataviz
repo: https://github.com/onaci/leaflet-velocity
author: Dan Wild
author-url: https://github.com/danwild
demo: https://onaci.github.io/leaflet-velocity/
compatible-v0:
compatible-v1: true
---

Visualise velocity layers with leaflet.
