---
name: Leaflet.glify
category: dataviz
repo: https://github.com/robertleeplummerjr/Leaflet.glify
author: robertleeplummerjr
author-url: https://github.com/robertleeplummerjr
demo: https://robertleeplummerjr.github.io/Leaflet.glify/
compatible-v0:
compatible-v1: true
---

Fast rendering for large (+100MB) GeoJSON datasets with WebGL.
