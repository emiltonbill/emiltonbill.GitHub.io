---
name: WP-Trip-Summary
category: 3rd-party-integration
repo: https://github.com/alexboia/WP-Trip-Summary/
author: Alexandru Boia
author-url: https://wordpress.org/plugins/wp-trip-summary/
demo: https://github.com/alexboia/WP-Trip-Summary/#screenshots
compatible-v0:
compatible-v1: true
---

A WordPress trip summary plugin to help travel bloggers manage and display structured information about their train rides and biking or hiking trips.
