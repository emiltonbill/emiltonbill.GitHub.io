---
name: Maps Marker Pro
category: 3rd-party-integration
repo: https://www.mapsmarker.com/
author: Robert Harm
author-url: https://www.harm.co.at/
demo: 
compatible-v0:
compatible-v1: true
---

A WordPress plugin that enables users to pin, organize and share their favorite places and tracks through their WordPress powered site.
