---
name: ABP Usermap MyBB
category: 3rd-party-integration
repo: https://community.mybb.com/mods.php?action=view&pid=1238
author: CrazyCat
author-url: https://gitlab.com/AnoBug
demo: 
compatible-v0:
compatible-v1: true
---

A plugin for <a href="https://mybb.com/">MyBB</a> creating a map of users based on Open Street Map and Leaflet, with customisable popup and markers
