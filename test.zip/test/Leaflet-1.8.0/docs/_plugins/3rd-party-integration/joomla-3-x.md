---
name: Joomla! (3.x)
category: 3rd-party-integration
repo: https://www.joomla.org/
author: Astrid Günther
author-url: https://github.com/astridx
demo: 
compatible-v0:
compatible-v1: true
---

<ul><li><strong>Agosm: </strong><br>Joomla Module not only for showing Markers on a OpenStreetMap Map.<br><a href="https://github.com/astridx/pkg_agosms">Gibhub</a></li><li><strong>Aggpxtrack: </strong><br>Joomla Custom Field for dispaying a GPX Track on a Map - you can choose an OpenStreetMap or GoogleMaps. With much options. For example: One option is an elevation profil.<br><a href="https://github.com/astridx/pkg_aggpxtrack">Gibhub</a></li><li><strong>Agosmmapwithmarker: </strong><br>Custom field for show a map with a marker in frond end - always the right card for the content. You can enter the address in backend.<br><a href="https://github.com/astridx/plg_fields_agosmmapwithmarker">Gibhub</a></li></ul>
