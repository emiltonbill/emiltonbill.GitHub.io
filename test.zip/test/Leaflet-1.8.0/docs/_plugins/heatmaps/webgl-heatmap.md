---
name: WebGL Heatmap
category: heatmaps
repo: https://github.com/ursudio/leaflet-webgl-heatmap
author: Benjamin J DeLong
author-url: http://ursudio.com/webgl-heatmap-leaflet/
demo: https://ursudio.github.io/leaflet-webgl-heatmap/
compatible-v0:
compatible-v1: true
---

High performance Javascript heatmap plugin using WebGL.
