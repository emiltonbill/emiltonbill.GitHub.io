---
name: Leaflet divHeatmap
category: heatmaps
repo: https://github.com/danielepiccone/leaflet-div-heatmap
author: Daniele Piccone
author-url: https://github.com/dpiccone
demo: 
compatible-v0:
compatible-v1: true
---

Lightweight and versatile heatmap layer based on CSS3 and divIcons
