---
name: Leaflet.ZoomPanel
category: interactive-pan-zoom
repo: https://github.com/will4906/leaflet.zoompanel
author: Shuhua Huang
author-url: https://github.com/will4906/
demo: https://will4906.github.io/leaflet-zoompanel/
compatible-v0:
compatible-v1: true
---

A Zoom Control Panel Of Leaflet.
