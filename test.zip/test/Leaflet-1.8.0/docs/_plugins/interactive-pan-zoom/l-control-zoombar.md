---
name: L.Control.ZoomBar
category: interactive-pan-zoom
repo: https://github.com/elrobis/L.Control.ZoomBar
author: Elijah Robison
author-url: http://cartometric.com/blog/
demo: https://elrobis.github.io/L.Control.ZoomBar/
compatible-v0:
compatible-v1: true
---

An extended version of Leaflet's native Zoom control with Home and Zoom-to-Area buttons.
