---
name: Leaflet.zoomhome
category: bookmarked-pan-zoom
repo: https://github.com/torfsen/leaflet.zoomhome
author: Florian Brucker
author-url: https://github.com/torfsen
demo: http://torfsen.github.io/leaflet.zoomhome/
compatible-v0:
compatible-v1: true
---

Zoom control with a home button for resetting the view.
