---
name: leaflet-view-meta
category: bookmarked-pan-zoom
repo: https://github.com/rwev/leaflet-view-meta
author: rwev
author-url: https://github.com/rwev
demo: https://rwev.github.io/leaflet-view-meta/
compatible-v0:
compatible-v1: true
---

Plugin control that displays and persists map view meta-data, center and boundary coordinates to URL for precise sharing and view reconstruction.
