---
name: leaflet-zoom-min
category: bookmarked-pan-zoom
repo: https://github.com/alanshaw/leaflet-zoom-min/
author: Alan Shaw
author-url: https://github.com/alanshaw/
demo: 
compatible-v0:
compatible-v1: true
---

Adds a button to the zoom control that allows you to zoom to the map minimum zoom level in a single click.
