---
name: Leaflet-Shades
category: area-overlay-selection
repo: https://github.com/mkong0216/leaflet-shades/
author: Mandy Kong
author-url: https://github.com/mkong0216
demo: https://mkong0216.github.io/leaflet-shades/examples/
compatible-v0:
compatible-v1: true
---

A draggable and resizable rectangle for selecting an area on a map and creating a gray overlay in unselected areas.
