---
name: Leaflet.FeatureSelect
category: area-overlay-selection
repo: https://github.com/openplans/Leaflet.FeatureSelect
author: Aaron Ogle
author-url: https://github.com/atogle
demo: http://openplans.github.io/Leaflet.FeatureSelect/
compatible-v0:
compatible-v1: true
---

Use a configurable centerpoint marker to select any geometry type from a GeoJSON layer.
