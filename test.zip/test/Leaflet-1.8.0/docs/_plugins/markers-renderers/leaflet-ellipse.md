---
name: Leaflet.ellipse
category: markers-renderers
repo: https://github.com/jdfergason/Leaflet.Ellipse
author: JD Fergason
author-url: https://github.com/jdfergason
demo: https://jdfergason.github.io/Leaflet.Ellipse/
compatible-v0:
compatible-v1: true
---

Leaflet.ellipse place ellipses on map by specifying center point, semi-major axis,			semi-minor axis, and tilt degrees from west.
