---
name: Leaflet Rotated Marker
category: markers-renderers
repo: https://github.com/bbecquet/Leaflet.RotatedMarker
author: Benjamin Becquet
author-url: https://github.com/bbecquet
demo: http://bbecquet.github.io/Leaflet.RotatedMarker/example.html
compatible-v0:
compatible-v1: true
---

Enables rotation of marker icons in Leaflet.
