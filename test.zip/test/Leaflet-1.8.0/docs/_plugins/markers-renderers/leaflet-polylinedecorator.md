---
name: Leaflet.PolylineDecorator
category: markers-renderers
repo: https://github.com/bbecquet/Leaflet.PolylineDecorator
author: Benjamin Becquet
author-url: https://github.com/bbecquet
demo: https://bbecquet.github.io/Leaflet.PolylineDecorator/example/example.html
compatible-v0:
compatible-v1: true
---

Allows you to draw patterns (like dashes, arrows or evenly spaced Markers) along Polylines or coordinate paths.
