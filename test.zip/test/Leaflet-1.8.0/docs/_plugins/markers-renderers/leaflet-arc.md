---
name: Leaflet.Arc
category: markers-renderers
repo: https://github.com/MAD-GooZe/Leaflet.Arc
author: Alexey Gusev
author-url: https://github.com/MAD-GooZe
demo: https://mad-gooze.github.io/Leaflet.Arc/
compatible-v0:
compatible-v1: true
---

This plugin adds L.Polyline.Arc function which wraps arc.js functionality for creation of Great Cirlce arcs.
