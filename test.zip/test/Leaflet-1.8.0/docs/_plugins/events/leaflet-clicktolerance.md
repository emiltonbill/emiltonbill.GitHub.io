---
name: Leaflet.ClickTolerance
category: events
repo: https://github.com/geoloep/Leaflet.ClickTolerance
author: Geoloep
author-url: https://github.com/geoloep
demo: 
compatible-v0:
compatible-v1: true
---

This plugin allows you to increase the click tolerance of canvas powered layers, making it possible to increase the clickable area of vector layers beyond their visible extent. Useful when your features are difficult to click otherwise.
