---
name: Leaflet-search
category: geocoding
repo: https://github.com/sjaakp/leaflet-search
author: Sjaak Priester
author-url: https://github.com/sjaakp
demo: https://sjaakpriester.nl/software/leaflet-search
compatible-v0:
compatible-v1: true
---

A Search Control with autocomplete/suggest capabilities. Supports Nominatim, GeoNames, Here, TomTom, and Kadaster (Netherlands).
