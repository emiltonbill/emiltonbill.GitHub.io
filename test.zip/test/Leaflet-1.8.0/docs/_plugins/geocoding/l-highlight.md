---
name: L.Highlight
category: geocoding
repo: https://github.com/mmaciejkowalski/L.Highlight
author: Maciej Kowalski
author-url: https://github.com/mmaciejkowalski
demo: https://mmaciejkowalski.github.io/L.Highlight/
compatible-v0:
compatible-v1: true
---

A plugin that adds the ability to quick highlighting streets and areas using <a href="https://nominatim.org/">Nominatim</a>.
