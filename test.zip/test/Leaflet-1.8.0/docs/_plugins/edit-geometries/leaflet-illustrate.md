---
name: Leaflet.Illustrate
category: edit-geometries
repo: https://github.com/justinmanley/Leaflet.Illustrate
author: Justin Manley
author-url: https://github.com/manleyjster
demo: https://justinmanley.github.io/Leaflet.Illustrate/examples/0.0.2/simple/
compatible-v0: true
compatible-v1: false
---

Extension for Leaflet.draw enabling users to type annotations directly on maps.
