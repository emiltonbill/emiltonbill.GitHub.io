---
name: Leaflet.SimpleMarkers
category: edit-geometries
repo: https://github.com/jdomingu/Leaflet.SimpleMarkers
author: Jared Dominguez
author-url: https://github.com/jdomingu
demo: 
compatible-v0:
compatible-v1: true
---

A light-weight Leaflet plugin for adding and deleting markers.
