---
name: Leaflet.FreeDraw
category: edit-geometries
repo: https://github.com/Wildhoney/Leaflet.FreeDraw
author: Wildhoney
author-url: https://github.com/Wildhoney
demo: https://github.com/Wildhoney/Leaflet.FreeDraw#readme
compatible-v0:
compatible-v1: true
---

Zoopla inspired freehand polygon creation using Leaflet.js and D3.
