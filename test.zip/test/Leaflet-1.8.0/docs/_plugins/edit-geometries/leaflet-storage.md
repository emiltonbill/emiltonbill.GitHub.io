---
name: Leaflet.Storage
category: edit-geometries
repo: https://github.com/umap-project/Leaflet.Storage
author: Yohan Boniface
author-url: https://yohanboniface.me/
demo: 
compatible-v0:
compatible-v1: true
---

Create/update/delete Map, Marker, Polygon, Polyline... and expose them for backend storage with an API.
