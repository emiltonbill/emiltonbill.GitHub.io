---
name: L.Control.BootstrapModal
category: frameworks-build-systems
repo: https://github.com/gregallensworth/L.Control.BootstrapModal
author: Greg Allensworth
author-url: https://github.com/gregallensworth
demo: 
compatible-v0:
compatible-v1: true
---

Trigger a Bootstrap modal using an on-map control.
