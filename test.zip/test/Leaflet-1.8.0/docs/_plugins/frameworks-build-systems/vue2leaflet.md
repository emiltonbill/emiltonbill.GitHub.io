---
name: Vue2Leaflet
category: frameworks-build-systems
repo: https://github.com/vue-leaflet/Vue2Leaflet
author: Mickaël KoRiGaN
author-url: https://github.com/KoRiGaN
demo: https://vue2-leaflet.netlify.app/quickstart/
compatible-v0:
compatible-v1: true
---

<a href="https://github.com/vue-leaflet/Vue2Leaflet">Vue2Leaflet</a> is a JavaScript library for the <a href="https://vuejs.org/">Vue.js</a> framework that wraps Leaflet, making it easy to create reactive maps.
