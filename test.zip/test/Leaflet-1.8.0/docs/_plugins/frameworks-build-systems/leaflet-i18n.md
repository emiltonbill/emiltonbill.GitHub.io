---
name: Leaflet.i18n
category: frameworks-build-systems
repo: https://github.com/yohanboniface/Leaflet.i18n
author: Yohan Boniface
author-url: https://yohanboniface.me/
demo: 
compatible-v0:
compatible-v1: true
---

Internationalization for Leaflet plugins.
