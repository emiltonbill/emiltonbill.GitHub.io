---
name: L.Control.jQueryDialog
category: frameworks-build-systems
repo: https://github.com/gregallensworth/L.Control.jQueryDialog
author: Greg Allensworth
author-url: https://github.com/gregallensworth
demo: http://gregallensworth.github.io/L.Control.jQueryDialog/
compatible-v0:
compatible-v1: true
---

Trigger a jQuery UI dialog/modal using an on-map control.
