---
name: leaflet-rails gem
category: frameworks-build-systems
repo: https://github.com/axyjo/leaflet-rails
author: Akshay Joshi
author-url: https://github.com/axyjo
demo: 
compatible-v0:
compatible-v1: true
---

This gem provides the leaflet.js map display library for your Rails 5 application. <a href="https://rubygems.org/gems/leaflet-rails">leaflet-rails on RubyGems</a>
