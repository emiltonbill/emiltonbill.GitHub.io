---
name: Leaflet ZoomLevel CSS Class
category: frameworks-build-systems
repo: https://github.com/dagjomar/Leaflet.ZoomCSS
author: Dag Jomar Mersland
author-url: https://github.com/dagjomar
demo: 
compatible-v0:
compatible-v1: true
---

Add zoom level css class to map element for easy style updates based on zoom levels
