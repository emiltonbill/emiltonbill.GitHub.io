---
name: YAGA leaflet-ng2
category: frameworks-build-systems
repo: https://github.com/yagajs/leaflet-ng2
author: YAGA Development Team
author-url: https://github.com/yagajs
demo:
compatible-v0:
compatible-v1: true
---

Granular integration into Angular2/4.
