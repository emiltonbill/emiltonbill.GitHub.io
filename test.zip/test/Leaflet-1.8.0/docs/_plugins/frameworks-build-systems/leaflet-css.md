---
name: Leaflet.CSS
category: frameworks-build-systems
repo: https://github.com/leaflet-extras/leaflet.css
author: Calvin Metcalf
author-url: https://github.com/calvinmetcalf
demo: https://leaflet-extras.github.io/leaflet.css/
compatible-v0:
compatible-v1: true
---

Add the main Leaflet CSS files (or any css) from within JavaScript, be gone conditional comments.
