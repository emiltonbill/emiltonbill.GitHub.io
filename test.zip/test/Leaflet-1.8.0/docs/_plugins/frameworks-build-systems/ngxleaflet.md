---
name: ngx-leaflet
category: frameworks-build-systems
repo: https://github.com/Asymmetrik/ngx-leaflet
author: Asymmetrik, Ltd.
author-url: https://asymmetrik.com/
demo: 
compatible-v0:
compatible-v1: true
---

Leaflet components and extensions for <a href="https://angular.io/">Angular.io</a>.
