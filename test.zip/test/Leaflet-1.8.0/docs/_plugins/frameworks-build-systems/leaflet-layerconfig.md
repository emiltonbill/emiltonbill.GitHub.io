---
name: Leaflet LayerConfig
category: frameworks-build-systems
repo: https://github.com/Norkart/Leaflet-LayerConfig
author: Alexander Nossum
author-url: https://github.com/alexanno
demo: 
compatible-v0:
compatible-v1: true
---

Provide a json file or service response with a configuration of layers and markers to automatically set up a Leaflet client.
