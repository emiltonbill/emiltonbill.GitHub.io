---
name: Leaflet Control Compass
category: geolocation
repo: https://github.com/stefanocudini/leaflet-compass
author: Stefano Cudini
author-url: https://opengeo.tech/
demo: https://opengeo.tech/maps/leaflet-compass/examples/simple.html
compatible-v0:
compatible-v1: true
---

A leaflet control plugin to build a simple rotating compass
