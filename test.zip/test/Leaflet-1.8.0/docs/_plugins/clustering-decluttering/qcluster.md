---
name: q-cluster
category: clustering-decluttering
repo: https://github.com/spatialdev/q-cluster
author: Nicholas Hallahan
author-url: https://github.com/hallahan
demo: http://spatialdev.github.io/q-cluster/demo/index.html
compatible-v0:
compatible-v1: true
---

Quick point clustering library with D3 categorization.
