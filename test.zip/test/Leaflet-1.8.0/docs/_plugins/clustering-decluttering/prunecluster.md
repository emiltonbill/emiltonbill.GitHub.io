---
name: PruneCluster
category: clustering-decluttering
repo: https://github.com/SINTEF-9012/PruneCluster
author: Antoine Pultier
author-url: https://github.com/yellowiscool
demo: http://sintef-9012.github.io/PruneCluster/examples/random.10000-size.html
compatible-v0:
compatible-v1: true
---

Fast and realtime marker clustering library.
