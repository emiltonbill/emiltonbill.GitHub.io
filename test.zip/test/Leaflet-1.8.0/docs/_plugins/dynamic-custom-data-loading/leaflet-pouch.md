---
name: Leaflet.Pouch
category: dynamic-custom-data-loading
repo: https://github.com/calvinmetcalf/leaflet.pouch
author: Calvin Metcalf
author-url: https://github.com/calvinmetcalf/
demo: 
compatible-v0:
compatible-v1: true
---

Use PouchDB to sync CouchDB data to local storage (indexedDB), to just add couchDB data or as just a less confusing implementation of indexedDB.
