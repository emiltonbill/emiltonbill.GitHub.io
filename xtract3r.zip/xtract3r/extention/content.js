const TA = document.querySelector('textarea')
      , _style = document.getElementById('style')
      , XTA = document.getElementById('extract')
      , result = document.getElementById('result')
      , progress = document.getElementById('progressbar')
      , btn_toggle = document.getElementsByClassName('form-check-input')[0]
      , textarea = document.getElementsByTagName('textarea')[0];

let toggle_state = 0;
textarea.disabled = true;
XTA.disabled = true;

btn_toggle.addEventListener('click', ()=>{
   toggle_state++;
   if(toggle_state == 1){
      textarea.disabled = false;
      XTA.disabled = false;
      let less = `
      body{
      min-width: 280px;
      min-height: 280px;
      background: #fff;
      filter: contrast(100%);
    }
.form-floating{
  height: 50px !important;
}

.progress-container {
  display: flex;
  justify-content: center;
  align-items: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%);
  height: 10vh; /* Full viewport height */
}

.progress-circle {
  position: relative;
  width: 100px; /* Diameter of the circle */
  height: 100px;
  background: #f1f1f1; /* Circle border */
  outline: 2px solid #f1f1f1;
  outline-offset: 28px;
  border-radius: 50%;
}

.ball {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 20px; /* Ball size */
  height: 20px;
  background: #fff; /* Ball color #ff6347*/
  outline: 2px solid #4444;
  outline-offset: -5px;
  border: 2px solid #f1f1f1;
  border-radius: 50%;
  transform: translate(-50%, -50%);
  animation: revolve 5s linear infinite;
}

@keyframes revolve {
  0% {
    transform: translate(-50%, -50%) rotate(0deg) translateX(80px) rotate(0deg);
  }
  100% {
    transform: translate(-50%, -50%) rotate(360deg) translateX(80px) rotate(-360deg);
  }
}


.name-title{
  color: #fff;
  scale:0.8;
  font-weight: bold;
}
.form-control{
  background: red;
}

hr{
  width: 60%;
  position: relative;
  left: 50%;
  transform: translate(-50%);
}

#state{
  position: absolute;
  left: 50%;
  z-index: 4;
  transform: translateX(-50%);
  font-weight: bold;
}

main{
  background: #fff;
  position: absolute;
  top:0;
  height: inherit;
  left: 50%;
  width: 100%;
  height: 100%;
  transform: translateX(-50%);
}

textarea::-webkit-input-placeholder{
  color: #4444;
}
      `;
_style.innerHTML = less;
   }else{
      toggle_state = 0;
      textarea.disabled = true;
      XTA.disabled = true;
      let css = `
      body{
      min-width: 280px;
      min-height: 280px;
      background: #fff;
      filter: contrast(100%);
    }
.form-floating{
  height: 50px !important;
}

.progress-container {
  display: flex;
  justify-content: center;
  align-items: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%);
  height: 10vh; /* Full viewport height */
}

.progress-circle {
  position: relative;
  width: 100px; /* Diameter of the circle */
  height: 100px;
  background: #f1f1f1; /* Circle border */
  outline: 2px solid #f1f1f1;
  outline-offset: 28px;
  border-radius: 50%;
}

.ball {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 20px; /* Ball size */
  height: 20px;
  background: #fff; /* Ball color #ff6347*/
  outline: 2px solid #4444;
  outline-offset: -5px;
  border: 2px solid #f1f1f1;
  border-radius: 50%;
  transform: translate(-50%, -50%);
  animation: revolve 5s linear infinite;
}

@keyframes revolve {
  0% {
    transform: translate(-50%, -50%) rotate(0deg) translateX(80px) rotate(0deg);
  }
  100% {
    transform: translate(-50%, -50%) rotate(0deg) translateX(80px) rotate(-0deg);
  }
}


.name-title{
  color: #fff;
  scale:0.8;
  font-weight: bold;
}
.form-control{
  background: red;
}

hr{
  width: 60%;
  position: relative;
  left: 50%;
  transform: translate(-50%);
}

#state{
  position: absolute;
  left: 50%;
  z-index: 4;
  transform: translateX(-50%);
  font-weight: bold;
}

main{
  background: #fff;
  position: absolute;
  top:0;
  height: inherit;
  left: 50%;
  width: 100%;
  height: 100%;
  transform: translateX(-50%);
}

textarea::-webkit-input-placeholder{
  color: #4444;
}
      `;
      _style.innerHTML = css;
   }
   console.log('clicked')
})

TA.addEventListener('input', (e)=>{
   const filter = e.target.value.split(' ').map(mix=> mix.replace(' ', ', '));
   TA.value = filter.toString().toUpperCase();

});

TA.addEventListener('change', (e)=>{
 const text = e.target.value;
 try{
  XTA.addEventListener('click', (e)=>{
    fetch('http://localhost:3600/post', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({data:text})}).then(response=>{
        if(!response.ok){
            throw new Error(`HTTP error! Status: ${response.status}`)
        }
        return response.json();
       }).then(data=>{
          console.log(data);
       if(data['num'] != 0){
         progress.animate([
            {width: '0%'},
            {width: '100%'}
          ], {
            duration: 100000,
            fill:'forwards',
            easing: 'ease',
            endDelay:1000
          }).addEventListener('finish', ()=>{
            result.innerHTML = "<span class='badge bg-success'>"+100+"+</span>";
          });
         }
       });
  });  
 }catch(error){
  console.log('systematic error -> ', error.message);
 }
});
