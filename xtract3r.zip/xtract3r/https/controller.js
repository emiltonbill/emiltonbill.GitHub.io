try {
  const { promises: dns } = require('dns')
  , env = require('dotenv').config()
  , fs = require('fs')  
  , Bottleneck = require('bottleneck')
  , path = require('path');   
  
  const limiter = new Bottleneck({
    maxConcurrent: 10, 
    minTime: 2000,
  });
  
    exports.ui = (req, res)=>{
                const data = req.body.data.split(',');
                data.forEach(DTA=>{
                  limiter.schedule(()=>searchGoogle(DTA, 100));
                })
  //'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''JAY365:V1.0.0''''''''''''''''''''''''''''''''''''''''''''
  async function searchGoogle(query, maxResults = 100) {
    const url = process.env.url;
    const resultsPerPage = 10; 
    
    let allResults = [];
    
    try {
      for (let start = 1; start <= maxResults; start += resultsPerPage) {
        const params = new URLSearchParams({
          key: process.env.gapi,
          cx: process.env.cx,
          q: query,
          start: start,
        });
  
        const response = await fetch(`${url}?${params}`);
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
  
        const data = await response.json();
        if (data.items) {
          allResults = allResults.concat(data.items);
        } else {
          console.log("No more results found.");
          break;
        }
  
        if (allResults.length >= maxResults) {
          break;
        }
      }
  
  
  
      allResults.forEach((item, index) => {
        extractEmailsFromWebsite(item.link, item.title);
      });
      res.send({num:allResults.length});
      return allResults.length;
    } catch (error) {
      console.error("Error performing search:", error.message);
    }
  }
  
  async function extractEmailsFromWebsite(url, title) {
    try {
  
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
  
      const html = await response.text();
  
      const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
      const emails = html.match(emailRegex);
  
      const uniqueEmails = emails ? [...new Set(emails)] : [];
      // console.log("Extracted Emails:", uniqueEmails);
      // return uniqueEmails;
      if(uniqueEmails || uniqueEmails.length > 0) {
        checkEmails(uniqueEmails);
      }
    } catch (error) {
      console.error("Error fetching the website:", error.message);
    }
  }
  
  const OFFICE365_MX = process.env.microsoft;
  
  
  async function isOffice365Email(email) {
    try {
  
      const domain = email.split('@')[1];
      if (!domain) throw new Error('Invalid email address.');
  
      const records = await dns.resolveMx(domain);
      if (!records || records.length === 0) {
        return { email, isOffice365: false, message: 'No MX records found' };
      }
  
      const isOffice365 = records.some((record) =>
        record.exchange.includes(OFFICE365_MX)
      );
  
      return { email, isOffice365, message: isOffice365 ? 'Office 365' : 'Other' };
    } catch (error) {
      return { email, isOffice365: false, message: error.message };
    }
  }
  
  
  async function checkEmails(emails) {
    const results = await Promise.all(emails.map(isOffice365Email));
    // console.log('Results:', results);
  
  
    const output = results
      .map((res) =>res != ''?`${res.email}: ${res.message}`:"--Empty Set: 0xx11EA")
      .join('\n');
    fs.appendFileSync('../email_results.txt', "}-----START-----{\r"+output+"\n}-----END-----{", 'utf-8');
    console.log('Results saved to email_results.txt');
  }
  
  //''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
  
  
    }
  } catch (error) {
      console.error(error);
  }
  