const Office365 = ()=>{
try {

      const express = require('express'),
      env = require('dotenv'),
      port = process.env.PORT || 3600,
      route = require('./route'),
      app = express(); 
      app.use(express.json());
      app.use(route);
      app.listen(port, (err)=>{
        err?console.error('systematic failure: ', err):console.log('Extension is ready, running at -> ', port);
      });
} catch (error) {
    console.error(error);
  }
}, { spawn } = require('child_process'), fs = require('fs');
let counticlock = 0;

const Agent = (e, a)=>{
   let agent = spawn(e, [...a], {shell:true});
       agent.stdout.on('data', (data)=>{
             console.error('status(stdout) -> ', data);
       });

       agent.stderr.on('data', (data)=>{
        console.error('status(stderr) -> ', data);
       });

       agent.on('error', (error)=>{
        console.error('status(error) -> ', error)
       });

       agent.on('close', (code)=>{
        if(code != 0) console.log('Agent exited (code) -> ', code);
        else console.log('Agent executed (code) -> ', code);


       });
}

  const read = fs.readFileSync(require('path').join(__dirname, '.env'), 'utf8'),
        data = read.split('execid=')[1].split('\n').map(strip=> strip.replace('\r', ''));
        let olv = data[0];
        ++olv;
        data[0] = 'execid=' + olv;
        let restruct = data.join('\n');
        fs.writeFileSync(require('path').join(__dirname, '.env'), restruct);

  const XTA = ()=>{

     Agent('npm', ['init','-y']);
     Agent('npm', ['install', 'dotenv', 'bottleneck', 'express', 'googleapis']); 
    }
olv == 1?XTA():Office365();
module.exports = { Agent }
      