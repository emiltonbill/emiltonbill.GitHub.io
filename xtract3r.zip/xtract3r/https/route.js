try {
const route = require('express').Router(),
      countroller = require('./controller');
      route.post('/post', countroller.ui);
      module.exports = route;
} catch (error) {
    console.error(error);
}
